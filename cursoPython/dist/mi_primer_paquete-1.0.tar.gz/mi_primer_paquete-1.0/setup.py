from setuptools import setup
#SETUP.PY es para trabajar con paquetes redistribuibles

setup(
    name="mi_primer_paquete",
    version="1.0", #cada vez q hacemos un cambio y lo volvemos a reempaquetar le vamos subiendo esta version
    description="primer paquete redistribuible",
    author="Ramirez Karen Denise",
    author_email="ramirezkarendenise@gmail.com",
    packages=["mi_primer_paquete"]
)